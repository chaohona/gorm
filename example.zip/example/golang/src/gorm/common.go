package gorm

const (
	CHECKDATAVERSION_AUTOINCREASE = 1
)
